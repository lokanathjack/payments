package com.microservices.payment.dao.jpa;

import org.springframework.data.repository.CrudRepository;

import com.microservices.payment.domain.Account;

public interface AccountRepository extends CrudRepository<Account, Long> {

	public Account findByname(String name);
}
